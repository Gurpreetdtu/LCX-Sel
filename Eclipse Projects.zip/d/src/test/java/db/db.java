package db;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class db {
	
	public static ExtentReports extent;
	
	public static ExtentSparkReporter spark;
	
	public static ExtentTest test;
	
	
	@BeforeMethod
	public void initialize() {
		
		System.out.println(System.getProperty("user.dir"));
		
		 extent = new ExtentReports();
		
		 spark = new ExtentSparkReporter(System.getProperty("user.dir") + "\\extentreports\\");
		
		spark.config().setReportName("First session");
		
		spark.config().setDocumentTitle("Document is C driver");
	
		spark.config().setTheme(Theme.DARK);
		
		spark.config().setEncoding("utf-8");
		
		extent.attachReporter(spark);
		
		 test = extent.createTest("Login Test");
		 
		
		test.log(Status.INFO, "starting login Test case");
		
		test.log(Status.INFO, "opening browser");
		
		test.log(Status.INFO, "validating presence of loginLink");
		
		test.log(Status.FAIL, "server 500");
		
		Assert.fail();
		
		test.log(Status.INFO, "Entering credentials");
		
		test.log(Status.PASS, "Login Test case PASS");
		
	}
		
		@AfterMethod
		
		
		public void finish() {
				extent.flush();
		}
		

}

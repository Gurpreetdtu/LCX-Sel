package Mob;

import org.testng.asserts.SoftAssert;

public class Testing_multiple {

	public static WebDriver driver;
	
	SoftAssert softassert = new SoftAssert();
	
	@Test
	
	public void MobileTest() {
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	
}

package TestCases;

import java.nio.file.spi.FileSystemProvider;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class soft_Hard_Assert {
	
	@Test
	public void Hardassertlogic() {
		
	 System.out.println("First hard assert");
	 Assert.assertTrue(true);
	 
	System.out.println("Second hard assert");
	 Assert.assertTrue(false);
	 
	 System.out.println("third hard assert");
	 Assert.assertTrue(true);}
	 
	 
	 @Test
	 public void softAssertloginn() {
	SoftAssert softassert = new SoftAssert();
			
		
		
			System.out.println("First Soft assert");
			softassert.assertTrue(true);
			
			System.out.println("Second Soft assert");
			softassert.assertTrue(false);
			 
			System.out.println("Third Soft assert");
			softassert.assertTrue(true);
 
	 }}


	
	
	



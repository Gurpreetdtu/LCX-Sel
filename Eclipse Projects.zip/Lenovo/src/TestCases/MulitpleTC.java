package TestCases;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.Test;

public class MulitpleTC {

	
	@Test
	public void critial() {
		String ExpectedOutput = "Teachng";
		String ActualOutput = "Teaching";
		Assert.assertEquals(ActualOutput, ExpectedOutput);				
		
	}
	
	@Test
	public void High() {
		boolean b1 = 1<2;
		boolean b2 = 3>4;
		Assert.assertTrue(b1, "b1!=b2, yes check karo");;
		
	}
	
	@Test
	public void Medium() {
		Assert.assertNotEquals("A1=A2", null);
	}
}



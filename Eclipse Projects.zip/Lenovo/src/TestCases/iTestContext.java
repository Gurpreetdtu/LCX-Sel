package TestCases;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.beust.jcommander.Strings;

public class iTestContext {
	
	@Test(priority=1)
	public void setUp(ITestContext context) {
		
		System.out.println("ABCD");
		context.setAttribute("Window10", "Lenovo");
		}
	
	@Test(priority=2, dependsOnMethods= "Setup")
	public void setup(ITestContext context) {
		System.out.println("XYZ");
		Strings operatingSystem = (Strings)context.getAttribute("Window");
		
		
		@Test(priority=3 ,dependsonMethods= "Setup, signIn")
		public void exit(ITestContext context){
			
			System.out.println("AVV");
			String OperatingSystem = (String)context.getAttribute("Www");
			System.out.println("Hello world " + operatingSystem);
			
			 
			
		}
	}
	
	

}

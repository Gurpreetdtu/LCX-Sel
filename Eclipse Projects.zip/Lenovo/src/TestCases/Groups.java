package TestCases;

import org.testng.annotations.Test;

public class Groups {

	@Test(groups= {"smoke"})
	public void TC1() {
		System.out.println("This is logic 1");		
	}
		
@Test(groups= {"smoke","sanity"})
public void TC2() {
	System.out.println("This is logic 2");	
	}
	
@Test(groups= {"smoke","sanity","regression"})
public void TC3() {
	System.out.println("This is logic 3");
	}

 
@Test(groups= {"sanity"})
public void TC4() {
	System.out.println("This is logic 4");
	}

}



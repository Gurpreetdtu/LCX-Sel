package TestCases;

import org.testng.annotations.Test;

public class Parllel {

	@Test
	public void TC1() {
		System.out.println("This output for TC1" + Thread.currentThread().getId());		
	}
		
@Test
public void TC2() {
	System.out.println("This output for TC2" + Thread.currentThread().getId());	
	}
	
@Test
public void TC3() {
	System.out.println("This output for TC3" + Thread.currentThread().getId());	
	}
}

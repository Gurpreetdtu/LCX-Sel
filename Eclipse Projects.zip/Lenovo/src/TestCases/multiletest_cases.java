	package TestCases;

import org.testng.annotations.Test;

import Mob.Nike;

public class multiletest_cases {
	
	@Test(priority=1, dataProviderClass = Nike.class, dataProvider= "getData" )
	public void launchUrl(String username, String password, int mobile) {
	//System.out.println();	
	}

	@Test(priority=2,dataProviderClass = Nike.class, dataProvider= "getData" )
	public void login(String username, String password, int mobile) {
		
	}
	
	@Test(priority=3,dataProviderClass = Nike.class, dataProvider= "getData" )
	public void validatehomepage(String username, String password, int mobile) {
		
	}
}

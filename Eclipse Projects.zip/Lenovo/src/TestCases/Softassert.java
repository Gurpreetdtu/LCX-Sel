package TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Softassert {
	
@Test	
 public void Softset() {
	 SoftAssert softassert = new SoftAssert();
	 
	 int i = 20; int j = 30;
	 
	 System.out.println("Sum of Two:" + (i+j)); 
	 
	 boolean b1 = 1>2; //true
	 boolean b2 = 3>4; //false
	 
	 softassert.assertEquals(b2,b1,"b2 is wrong");
	 
	 softassert.assertAll();
	  
	 }
 }



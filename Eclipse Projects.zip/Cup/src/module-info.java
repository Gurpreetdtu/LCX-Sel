/**
 * 
 */
/**
 * @author Administrator
 *
 */
module Cup {
	requires org.seleniumhq.selenium.grid;
}
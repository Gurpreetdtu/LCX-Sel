package snippet;

public class operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a = 1;
		int b = 2;
		
//		if (a == b){
//		
//			System.out.println("3");
//		}
//		else	{
//			
//			System.out.println("4");
//			
			
			
			
		if ( b||a ) {
			
			System.out.print("Tre");
		}
		
		else
			
			System.out.println("false");
			
		 
		}
		

	}



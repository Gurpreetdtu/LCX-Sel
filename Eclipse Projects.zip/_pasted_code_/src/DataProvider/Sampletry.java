package DataProvider;

public class Sampletry {

}

package SampleDDF;

public class Sample {

}
